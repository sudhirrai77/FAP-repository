package com.sggsiet.farmerportal.entity;

public class ProductType {

}
