package com.sggsiet.farmerportal.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/admin")
public class AdminController {

	
	
	@GetMapping("/main_dashboard")
	public String mainDashboard()
	{
		return "FrontEnd/dashboard";
	}
	
	 @PostMapping("/admin_dashboard")
	  public String AdminDashboard(@RequestParam String username,@RequestParam String password,Model model)
	  {
		 
		  System.out.println("username :"+username);
		  System.out.println("password :"+password);
		  
		  if(username.equals("admin") && password.equals("pass")) {
			  
			  model.addAttribute("success_message", "Successfully logged in");
			  return "FrontEnd/Admin/html/admin_dashboard";
			
		  }else {
		  model.addAttribute("error_message", " log in failed");
		  
		  return "FrontEnd/admin_login";
		  }
		 
	  }
	  
	 
	  
	 
	  
	 
}
