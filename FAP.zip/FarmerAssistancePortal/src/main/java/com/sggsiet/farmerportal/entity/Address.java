package com.sggsiet.farmerportal.entity;

public class Address {

}
