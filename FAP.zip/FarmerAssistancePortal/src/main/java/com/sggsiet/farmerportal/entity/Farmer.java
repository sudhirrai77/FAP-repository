package com.sggsiet.farmerportal.entity;

public class Farmer {

}
