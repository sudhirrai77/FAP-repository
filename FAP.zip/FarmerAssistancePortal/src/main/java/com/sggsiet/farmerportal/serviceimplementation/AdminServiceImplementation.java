package com.sggsiet.farmerportal.serviceimplementation;

import org.springframework.stereotype.Service;

@Service
public class AdminServiceImplementation {

}
