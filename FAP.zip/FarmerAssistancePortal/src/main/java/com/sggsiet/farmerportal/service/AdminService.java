package com.sggsiet.farmerportal.service;


public interface AdminService {

}
