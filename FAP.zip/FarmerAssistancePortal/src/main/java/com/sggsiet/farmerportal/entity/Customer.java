package com.sggsiet.farmerportal.entity;

public class Customer {

}
