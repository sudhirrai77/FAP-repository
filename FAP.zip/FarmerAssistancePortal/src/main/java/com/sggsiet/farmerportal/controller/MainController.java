package com.sggsiet.farmerportal.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/farmerportal")
public class MainController {
	@GetMapping("/main_dashboard")
	public String mainDashboard()
	{
		return "FrontEnd/dashboard";
	}
	 @GetMapping("/admin_login") 
	  public String adminLogin() 
	  { 
		  return "FrontEnd/admin_login"; 
	  }
	 @GetMapping("/customer_login") 
	  public String customerLogin() 
	  { 
		  return "FrontEnd/customer_login"; 
	  }
	 @GetMapping("/about_us")
		public String aboutUs()
		{
			return "FrontEnd/about_us";
		}
	@GetMapping("/all_product")
	public String allProduct()
	{
		return "FrontEnd/Home/html/all_product";
	}
	@GetMapping("/notifications")
	public String notifications()
	{
		return "FrontEnd/Home/html/notifications";
	}
	@GetMapping("/all_questions")
	public String allQuestions()
	{
		return "FrontEnd/Home/html/all_questions";
	}
	@GetMapping("/register")
	public String register()
	{
		return "FrontEnd/Home/html/register";
	}
	@GetMapping("/login")
	public String login()
	{
		return "FrontEnd/Home/html/login";
	}
	
	@GetMapping("/contact_us")
	public String contactUs()
	{
		return "FrontEnd/Home/html/contact_us";
	}
	
}
