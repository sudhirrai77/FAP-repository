package com.sggsiet.farmerportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.sggsiet.farmerportal.entity.Admin;
import com.sggsiet.farmerportal.entity.Customer;
import com.sggsiet.farmerportal.entity.Experts;
import com.sggsiet.farmerportal.entity.Farmer;
import com.sggsiet.farmerportal.entity.Notifications;
import com.sggsiet.farmerportal.entity.Orders;
import com.sggsiet.farmerportal.entity.PasswordChange;
import com.sggsiet.farmerportal.entity.Product;
import com.sggsiet.farmerportal.service.MainService;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private MainService adminService;
	
	Customer Globalcustomer;
	Farmer GlobalFarmer;
	Experts GlobalExpert;
	
	@GetMapping("/main_dashboard")
	public String mainDashboard()
	{
		return "dashboard";
	}
	
	@GetMapping("/reports")
	public String reports()
	{
		return "FrontEnd/Admin/html/reports";
	}
	
	@GetMapping("/change_password_admin")
	public String changePasswordAdmin()
	{
		return "FrontEnd/Admin/html/change_password";
	}
	
	@GetMapping("/change_password_farmer")
	public String changePasswordFarmer()
	{
		
		return "FrontEnd/Farmer/html/change_password";
	}
	@PostMapping("/change_password_farmer")
	public String changePasswordFarmer(@ModelAttribute PasswordChange passwordChange,Model model)
	{
		System.out.println("old password"+passwordChange.getOld_password());
		System.out.println("new password"+passwordChange.getNew_password());

		model.addAttribute("success_message", "password changed successfully");
		return "FrontEnd/Farmer/html/change_password";
	}
	@GetMapping("/change_password_expert")
	public String changePasswordExpert()
	{
		return "FrontEnd/Admin/html/change_password2";
	}
	@GetMapping("/change_password_customer")
	public String changePasswordCustomer()
	{
		
		return "FrontEnd/Customer/html/change_password";
	}
	
	
	
	@GetMapping("/admin_dashboard")
	public String AdminDashboard()
	{
		return "FrontEnd/Admin/html/admin_dashboard";
	}
	
	  
	 //............................Admin Login...................
	 @GetMapping("/admin_login") 
	  public String adminLogin() 
	  { 
		  return "FrontEnd/admin_login"; 
	  }
	 @PostMapping("/admin_login")
	  public String AdminLogin(@RequestParam String username,@RequestParam String password,Model model)
	  {
		 
			
			  Admin admin=adminService.getAdminData(); 
			  System.out.println("username :"+admin.getUsername());
			  System.out.println("password :"+admin.getPassword());
			  if(username.equals(admin.getUsername()) && password.equals(admin.getPassword())) { 
			  model.addAttribute("success_message", "Successfully logged in"); return
			  "FrontEnd/Admin/html/admin_dashboard";
			  }
			  model.addAttribute("error_message", " log in failed");
			 
		  return "FrontEnd/admin_login";
		
	  }
	 
	 
	//..........................Customer Login...................................
		 @GetMapping("/customer_login") 
		  public String customerLogin() 
		  { 
			  return "FrontEnd/customer_login"; 
		  }
		 
		 @PostMapping("/customer_login")
		  public String customerLoginC(@RequestParam String username,@RequestParam String password,Model model)
		  {
			 System.out.println("username :"+username);
			 System.out.println("password :"+password);
			 List<Product> listOfProducts=adminService.getAllProduct();
			 List<Customer> customerList= adminService.getAllCustomers();
			 for( Customer customer:customerList)
				  if(username.equals(customer.getUsername()) && password.equals(customer.getPassword()))
				  	{
					     Globalcustomer=customer;
					     model.addAttribute("Globalcustomer", Globalcustomer);
					     model.addAttribute("listOfProducts", listOfProducts);
				         model.addAttribute("success_message", "Successfully logged in");
				      return "FrontEnd/Customer/html/customer_dashboard";
				
				  	}
			 model.addAttribute("error_message", " log in failed");
			 return "FrontEnd/customer_login";
		  }
		 @GetMapping("/customer_dashboard")
			public String customerDashboard(Model model)
			{
			 model.addAttribute("Globalcustomer", Globalcustomer);
				List<Product> listOfProducts=adminService.getAllProduct();
				model.addAttribute("listOfProducts", listOfProducts);

				return "FrontEnd/Customer/html/customer_dashboard";
			}
			@GetMapping("/my_orders/{customer_id}")
			public String myOrder(@RequestParam("customer_id") int customer_id ,Model model)
			{
				List<Orders> listOfOrders=adminService.getOrdersByCustomerId(customer_id);
				model.addAttribute("listOfOrders", listOfOrders);
				model.addAttribute("Globalcustomer", Globalcustomer);
				return "FrontEnd/Customer/html/my_orders";
			}
	 
	 
	//.....................Farmer Login..........................
	
	 @GetMapping("/farmer_login") 
	  public String farmerLogin() 
	  { 
		  return "FrontEnd/Farmer/html/farmer_login"; 
	  }
	 @PostMapping("/farmer_login")
	  public String farmerLogin(@RequestParam String username,@RequestParam String password,Model model)
	  {
		 System.out.println("username :"+username);
		  System.out.println("password :"+password);
			  List<Farmer> farmerList= adminService.getAllFarmers();
			  for(Farmer farmer:farmerList)
			  {
			  if(username.equals(farmer.getUsername()) && password.equals(farmer.getPassword()))
			  
			  {
					  GlobalFarmer=farmer;
					  model.addAttribute("farmer", farmer);
					  model.addAttribute("success_message", "Successfully logged in");
			  return "FrontEnd/Farmer/html/farmer_dashboard";
			  
			  }
			  }
			  model.addAttribute("error_message", "log in failed");
			 
		  return "FrontEnd/Farmer/html/farmer_login";
		
	  } 
	 @GetMapping("/farmer_dashboard")
		public String farmerDashboard(Model model)
		{
			List<Customer> listOfCustomer=adminService.getCustomer();
			model.addAttribute("GlobalFarmer", GlobalFarmer);
			model.addAttribute("listOfCustomer", listOfCustomer);
			
			return "FrontEnd/Farmer/html/farmer_dashboard";
		}

	//......................Expert Login.....................................
	 @GetMapping("/expert_login") 
	  public String expertLogin() 
	  { 
		  return "FrontEnd/expert_login"; 
	  }
	 @PostMapping("/expert_login")
	  public String ExpertLogin(@RequestParam String username,@RequestParam String password,Model model)
	  {
		  System.out.println("username :"+username);
		  System.out.println("password :"+password);
		  List<Experts> expertList= adminService.getAllExperts();
		  for(Experts expert:expertList)
		  {
		  if(username.equals(expert.getUsername()) && password.equals(expert.getPassword())) {
			  
			  GlobalExpert=expert;
			  model.addAttribute("expert", expert);
			  model.addAttribute("success_message", "Successfully logged in");
			  return "FrontEnd/Admin/html/expert_dashboard";
			
		  }
		  }
		  model.addAttribute("error_message", " log in failed");
		  
		  return "FrontEnd/Admin/html/expert_login";
		  
		 
	  }
	 @GetMapping("/expert_dashboard")
		public String expertDashboard(Model model)
		{
			
			List<Notifications> listOfNotifications=adminService.getAllNotifications();
			 model.addAttribute("listOfNotifications", listOfNotifications);
		 model.addAttribute("GlobalExpert", GlobalExpert);
			return "FrontEnd/Admin/html/expert_dashboard";
		}
	 
	 
	 
	  
	 
	  
	 
}
