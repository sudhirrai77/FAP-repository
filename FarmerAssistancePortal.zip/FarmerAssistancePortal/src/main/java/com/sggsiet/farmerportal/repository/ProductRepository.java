package com.sggsiet.farmerportal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sggsiet.farmerportal.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{



	List<Product> findByType(String type);

	Product findByName(String name);

}
