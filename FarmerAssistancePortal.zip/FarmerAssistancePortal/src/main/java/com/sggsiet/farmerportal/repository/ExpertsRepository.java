package com.sggsiet.farmerportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sggsiet.farmerportal.entity.Experts;

public interface ExpertsRepository extends JpaRepository<Experts, Integer> {

}
