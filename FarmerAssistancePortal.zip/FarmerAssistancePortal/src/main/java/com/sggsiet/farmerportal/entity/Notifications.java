package com.sggsiet.farmerportal.entity;




import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.Transient;

@Entity
public class Notifications {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String title;
	
	private String image;
	
	private Date date;
	private String description;
	
	
	
	
	public Notifications() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Notifications(int id, String title, String image, Date date, String description) {
		super();
		this.id = id;
		this.title = title;
		this.image = image;
		this.date = date;
		this.description = description;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	@Transient
	public String getPhotosImagePath() {

		if (image == null) 	return null;
		
		return "/notify-photos/" + id + "/" + image;

	}
	
	

}
