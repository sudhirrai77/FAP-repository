package com.sggsiet.farmerportal.service;

import java.util.List;
import java.util.Optional;

import com.sggsiet.farmerportal.entity.Admin;
import com.sggsiet.farmerportal.entity.AskQuestions;
import com.sggsiet.farmerportal.entity.Customer;
import com.sggsiet.farmerportal.entity.Experts;
import com.sggsiet.farmerportal.entity.Farmer;
import com.sggsiet.farmerportal.entity.Notifications;
import com.sggsiet.farmerportal.entity.Orders;
import com.sggsiet.farmerportal.entity.Product;


public interface MainService {

	void saveFarmer(Farmer farmer);

	void saveProduct(Product product);

	Admin getAdminData();

	void saveCustomer(Customer customer);

	void saveExpert(Experts expert);

	List<Farmer> getAllFarmers();

	List<Customer> getCustomer();

	void saveQuestion(AskQuestions askQuestions);

	List<AskQuestions> getAllQuestions();

	List<Experts> getAllExpert();

	List<Farmer> getAllFarmer();

	List<Customer> getAllCustomers();

	AskQuestions getQuestion(String farmerName);

	List<AskQuestions> getMyQuestions(String farmername);

	List<Product> getAllProduct();

	void saveNotification(Notifications notifications);

	List<Product> getProductByType(String type);

	List<Experts> getAllExperts();

	List<Notifications> getAllNotifications();

	List<Orders> getOrdersByCustomerId(int customer_id);

	Optional<Product> getProductById(int id);

	void updateProductType(Product product);

	Optional<Experts> getExpertById(int id);

	void updateExpert(Experts experts);

	Optional<Customer> getCustomerById(int id);

	void updateCustomer(Customer customer);

	Optional<Farmer> getFarmerById(int id);

	void updateFarmer(Farmer farmer);

	void addAnswer(String answer);

	

	
	

}
