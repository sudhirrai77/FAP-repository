package com.sggsiet.farmerportal.serviceimplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sggsiet.farmerportal.entity.Admin;
import com.sggsiet.farmerportal.entity.AskQuestions;
import com.sggsiet.farmerportal.entity.Customer;
import com.sggsiet.farmerportal.entity.Experts;
import com.sggsiet.farmerportal.entity.Farmer;
import com.sggsiet.farmerportal.entity.Notifications;
import com.sggsiet.farmerportal.entity.Orders;
import com.sggsiet.farmerportal.entity.Product;
import com.sggsiet.farmerportal.repository.AdminRepository;
import com.sggsiet.farmerportal.repository.AskQuestionRepository;
import com.sggsiet.farmerportal.repository.CustomerRepository;
import com.sggsiet.farmerportal.repository.ExpertRepository;
import com.sggsiet.farmerportal.repository.ExpertsRepository;
import com.sggsiet.farmerportal.repository.FarmerRepository;
import com.sggsiet.farmerportal.repository.NotificationsRepository;
import com.sggsiet.farmerportal.repository.OrdersRepository;
import com.sggsiet.farmerportal.repository.ProductRepository;
import com.sggsiet.farmerportal.service.MainService;



@Service
public class MainServiceImplementation implements MainService{
	@Autowired
	private FarmerRepository FarmerRepository;
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private ExpertsRepository expertsRepository;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private AskQuestionRepository askQuestionRepository;
	
	@Autowired
	private ExpertRepository expertRepository;
	@Autowired
	private NotificationsRepository notificationsRepository;
	@Autowired
	private OrdersRepository orderRepository;
	
	
	

	@Override
	public void saveFarmer(Farmer farmer) {
		FarmerRepository.save(farmer);
		
	}

	@Override
	public void saveProduct(Product product) {
		productRepository.save(product);
		
	}

	@Override
	public Admin getAdminData() {
		
		String admin="admin";
		return adminRepository.findByUsername(admin);
	}

	@Override
	public void saveCustomer(Customer customer) {
		
		customerRepository.save(customer);
	}

	@Override
	public void saveExpert(Experts expert) {
		
		expertsRepository.save(expert);
	}

	@Override
	public List<Farmer> getAllFarmers() {
		
		return FarmerRepository.findAll();
	}

	@Override
	public List<Customer> getCustomer() {
		
		return customerRepository.findAll();
	}

	@Override
	public void saveQuestion(AskQuestions askQuestions) {
		askQuestionRepository.save(askQuestions);
		
	}

	@Override
	public List<AskQuestions> getAllQuestions() {
		
		return askQuestionRepository.findAll();
	}

	@Override
	public List<Experts> getAllExpert() {
		
		return expertRepository.findAll();
	}

	@Override
	public List<Farmer> getAllFarmer() {
		
		return FarmerRepository.findAll();
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customerRepository.findAll();
	}

	@Override
	public AskQuestions getQuestion(String farmerName) {
		return askQuestionRepository.findByFarmerName(farmerName);
	}

	@Override
	public List<AskQuestions> getMyQuestions(String farmername) {
		
		return askQuestionRepository.findAllByfarmerName(farmername);
	}

	@Override
	public List<Product> getAllProduct() {
		
		return productRepository.findAll();
		
	}

	@Override
	public void saveNotification(Notifications notifications) {
		notificationsRepository.save(notifications);
		
	}

	@Override
	public List<Product> getProductByType(String type) {
		
		return productRepository.findByType(type);
	}

	@Override
	public List<Experts> getAllExperts() {
		
		return expertRepository.findAll();
	}

	@Override
	public List<Notifications> getAllNotifications() {
		
		return notificationsRepository.findAll();
	}

	@Override
	public List<Orders> getOrdersByCustomerId(int customer_id) {
		
		return null;
	}

	@Override
	public Optional<Product> getProductById(int id) {
		
		return productRepository.findById(id);
	}

	@Override
	public void updateProductType(Product product) {
		Product product1=productRepository.findByName(product.getName());
		product1.setType(product.getType());
		
		productRepository.save(product1);
		
		
	}

	@Override
	public Optional<Experts> getExpertById(int id) {
		
		return expertRepository.findById(id);
	}

	@Override
	public void updateExpert(Experts experts) {
		Experts expert=expertRepository.findByName(experts.getName());
		expert.setMobile(experts.getMobile());
		expert.setDepartment(experts.getDepartment());
		expert.setEmail(experts.getEmail());
		expert.setStatus(experts.getStatus());
		
	}

	@Override
	public Optional<Customer> getCustomerById(int id) {
		
		return customerRepository.findById(id);
	}

	@Override
	public void updateCustomer(Customer customer) {
		Customer customer1=customerRepository.findByName(customer.getName());
		customer1.setEmail(customer.getEmail());;
		customer1.setMobile(customer.getMobile());
		customer1.setUsername(customer.getUsername());
		
	}

	@Override
	public Optional<Farmer> getFarmerById(int id) {
		
		return FarmerRepository.findById(id);
	}

	@Override
	public void updateFarmer(Farmer farmer) {
		Farmer farmer1=FarmerRepository.findByFirstname(farmer.getFirstname());
		farmer1.setMiddlename(farmer.getMiddlename());
		farmer1.setLastname(farmer.getLastname());
		farmer1.setEmail(farmer.getEmail());
		farmer1.setMobile(farmer.getPassword());
		farmer1.setStatus(farmer.getStatus());
		
		FarmerRepository.save(farmer1);
		
	}

	@Override
	public void addAnswer(String answer) {
		
	}

	

}
