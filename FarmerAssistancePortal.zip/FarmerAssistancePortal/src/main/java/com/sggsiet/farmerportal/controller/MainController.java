package com.sggsiet.farmerportal.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.sggsiet.farmerportal.entity.AskQuestions;
import com.sggsiet.farmerportal.entity.Customer;
import com.sggsiet.farmerportal.entity.Experts;
import com.sggsiet.farmerportal.entity.Farmer;
import com.sggsiet.farmerportal.entity.Product;
import com.sggsiet.farmerportal.service.MainService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/farmerportal")
public class MainController {
	@Autowired
	private MainService mainService;
	
	
	@GetMapping("/main_dashboard")
	public String mainDashboard()
	{
		return "dashboard";
	}
	
	
	//.........................customer registration...................................
	@GetMapping("/customer_registration")
	public String customerRegistration()
	{
		return "FrontEnd/Customer/html/customer_registration";
	}
	@PostMapping("/customer_registration")
	public String customerRegister( @ModelAttribute(value="customer") Customer customer,Model model)
	{
		
		
			mainService.saveCustomer(customer);
			model.addAttribute("success_message", "User Added Succesfully");
			return "FrontEnd/customer_login";
			
	}
	
	
	
	//............................product registration..............................
	
	@GetMapping("/product_registration")
	public String productRegistration()
	{
		//model.addAttribute("product", new Product());
		
		return "FrontEnd/Product/html/addnew_product";
	}
	
	@PostMapping("/product_registration")
	public String register(@ModelAttribute Product product, @RequestParam MultipartFile file ,Model model) throws IOException
	{
		System.out.println(product.getName());
		System.out.println(file.isEmpty());
		String fileName=file.getOriginalFilename();
		
		
		String uploadDirectory="C:\\Users\\RaiS02\\eclipse-workspace\\FarmerAssistancePortal\\uploadedFiles";
		
		FileUploader.saveDoc(uploadDirectory, fileName, file);
		
		System.out.println("file Uploaded succefullly");
		//mainService.saveProduct(product);
		
		
		return "FrontEnd/Product/html/addnew_product";
	}
	
	
	
	//.........................farmer registration.............................
	
	
	@GetMapping("/farmer_dashboard")
	public String farmerDashboard(Model model)
	{
		List<Customer> listOfCustomer=mainService.getCustomer();
		
		for(Customer customer:listOfCustomer)
		{
			System.out.println(customer.getName());
		}
		model.addAttribute("listOfCustomer", listOfCustomer);
		
		return "FrontEnd/Farmer/html/farmer_dashboard";
	}
	
	@GetMapping("/farmer_registration")
	public String registration(Model model)
	{
		model.addAttribute("farmer", new Farmer());
		
		return "FrontEnd/Farmer/html/farmer_registration";
	}
	@GetMapping("/Afarmer_registration")
	public String Fregistration(Model model)
	{
		model.addAttribute("farmer", new Farmer());
		
		return "FrontEnd/Admin/html/farmer_registration";
	}
	@PostMapping("/farmer_registration")
	public String register(@Valid @ModelAttribute(value="farmer") Farmer farmer,BindingResult bindingResult ,Model model)
	{
		
		if(bindingResult.hasErrors())
		{	
			model.addAttribute("error_message", "validation error ");	
			return "FrontEnd/Farmer/html/farmer_registration";
		}else {
			mainService.saveFarmer(farmer);
			model.addAttribute("success_message", "User Added Succesfully");
			return "FrontEnd/Farmer/html/farmer_login";
		}		
	}
	
	@GetMapping("/ask_question")
	public String askQuestion()
	{
		
		return "FrontEnd/Farmer/html/ask_question";
	}
	@PostMapping("/ask_question")
	public String askQuestion(@ModelAttribute AskQuestions askQuestions ,Model model) throws IOException
	{
	
		model.addAttribute("success_message", "Question Submitted");
		System.out.println(askQuestions.getFarmerName());
		System.out.println(askQuestions.getQuestion());
		
		return "FrontEnd/Farmer/html/ask_question";
	}
	
	

	//................Expert Registration..................
	
	@GetMapping("/add_expert")
	public String addExpert()
	{
		return "FrontEnd/Admin/html/add_expert";
	}
	@PostMapping("/add_expert")
	public String expertRegister( @ModelAttribute(value="expert") Experts expert,Model model)
	{
		mainService.saveExpert(expert);
			model.addAttribute("success_message", "User Added Succesfully");
			return "FrontEnd/Admin/html/add_expert";		
	}
	
	
	//................................................................
	
	 @GetMapping("/about_us")
		public String aboutUs()
		{
			return "FrontEnd/about_us";
		}
	@GetMapping("/all_product")
	public String allProduct( Model model)
	{
		model.addAttribute("allproduct", "this is all product");
		
		return "FrontEnd/Home/html/all_product";
	}
	@GetMapping("/all_product_a")
	public String allProductA( Model model)
	{
		model.addAttribute("allproduct", "this is all product");
		
		return "FrontEnd/AdminReports/html/all_products";
	}
	@GetMapping("/notifications")
	public String notifications()
	{
		return "FrontEnd/Home/html/notifications";
	}
	@GetMapping("/all_notifications")
	public String allNotifications()
	{
		return "FrontEnd/AdminReports/html/all_notifications";
	}
	
	@GetMapping("/all_experts")
	public String allExperts()
	{
		return "FrontEnd/AdminReports/html/all_experts";
	}
	@GetMapping("/all_farmers")
	public String allFarmers()
	{
		return "FrontEnd/AdminReports/html/all_farmers";
	}
	@GetMapping("/all_customers")
	public String allCustomers()
	{
		return "FrontEnd/AdminReports/html/All_customers";
	}
	@GetMapping("/all_questions")
	public String allQuestions()
	{
		return "FrontEnd/Home/html/all_questions";
	}
	@GetMapping("/all_questionsE")
	public String allQuestionsE()
	{
		return "FrontEnd/Admin/html/all_questions";
	}
	@GetMapping("/contact_us")
	public String contactUs()
	{
		return "FrontEnd/Home/html/contact_us";
	}
	
	
	
}
