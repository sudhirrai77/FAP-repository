package com.sggsiet.farmerportal.controller;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import com.sggsiet.farmerportal.entity.AskQuestions;
import com.sggsiet.farmerportal.entity.ContactUs;
import com.sggsiet.farmerportal.entity.Customer;
import com.sggsiet.farmerportal.entity.Experts;
import com.sggsiet.farmerportal.entity.Farmer;
import com.sggsiet.farmerportal.entity.Notifications;
import com.sggsiet.farmerportal.entity.Product;
import com.sggsiet.farmerportal.service.MainService;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/farmerportal")
public class MainController {
	@Autowired
	private MainService mainService;
	
	
	@GetMapping("/main_dashboard")
	public String mainDashboard()
	{
		return "dashboard";
	}
	
	
	//.........................customer registration...................................
	@GetMapping("/customer_registration")
	public String customerRegistration()
	{
		return "FrontEnd/Customer/html/customer_registration";
	}
	@PostMapping("/customer_registration")
	public String customerRegister( @ModelAttribute(value="customer") Customer customer,Model model)
	{
		
		
			mainService.saveCustomer(customer);
			model.addAttribute("success_message", "Form Submitted Succesfully");
			return "FrontEnd/customer_login";
			
	}
	
	
	
	@GetMapping("/select_items/{type}")
	public String selectItems(@PathVariable("type") String type,Model model)
	{
		System.out.println("type :"+type);
		List<Product> listOfProducts=mainService.getProductByType(type);
		model.addAttribute("listOfProducts", listOfProducts);
		return "/FrontEnd/Customer/html/select_items";
	}
	

	
	@PutMapping("/my_account")
	public String myAccount()
	{
		
		return "";
	}
	
	
	
	
	
	
	
	//............................product registration..............................
	
	@GetMapping("/product_registration")
	public String productRegistration()
	{
		//model.addAttribute("product", new Product());
		
		return "FrontEnd/Product/html/addnew_product";
	}
	
	@RequestMapping(value="/product_registration",method = RequestMethod.POST,consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public String register(Product product, @RequestPart("name") String name,
			@RequestPart(required = true,value = "productImage") MultipartFile productImage ,
			@RequestPart("price") String price,
			@RequestPart("type") String type,
			@RequestPart("company") String company,Model model) throws IOException
	{
		
		
		String fileName = StringUtils.cleanPath(productImage.getOriginalFilename());

		List<Product> listOfProducts = new ArrayList<>();

		//allImg = repo.findAll();
		listOfProducts=mainService.getAllProduct();
		

		String uploadDir = "user-photos/" + (listOfProducts.size()+1);

		try {

			//System.out.println("FileUploadUtil ");
		  FileUploader.saveDoc(uploadDir, fileName, productImage);

	      product.setImage(fileName);

	
		} 
		catch(IOException ie) {

			System.out.println("Error! file upload "+ie.getMessage());

		}
		//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		
		product.setName(name);
		product.setPrice(price);
		product.setCompany(company);
		product.setType(type);				
		mainService.saveProduct(product);
		listOfProducts=mainService.getAllProduct();
		model.addAttribute("listOfProducts", listOfProducts);
		
		return "FrontEnd/Product/html/addnew_product";
	}
	
	
//.............update product type

	@GetMapping("/product_type")
	public String productType(Model model)
		{
		List<Product> listOfProducts=mainService.getAllProduct();
		model.addAttribute("listOfProducts", listOfProducts);
			return "FrontEnd/Admin/html/product_type";
	
		}
	
	
	//.......................product update................................
	
	@GetMapping("/update_product_type/{id}")
	public String ProductType(@PathVariable int id,Model model)
	{
		System.out.println("id :"+id);
	
		Optional<Product> product=mainService.getProductById(id);
		model.addAttribute("product", product);

		
		return "FrontEnd/Admin/html/update_product_type";
	}
	@PostMapping("/update_product_type")
	public String UpdateProductType(@ModelAttribute Product product, Model model)
	{
		
		System.out.println("name :"+product.getName());
		System.out.println("type :"+product.getType());

	mainService.updateProductType(product);
		

		
		return "FrontEnd/Admin/html/update_product_type";
	}
	//........................................expert update.....................
	
	@GetMapping("/edit_expert/{id}")
	public String expertUpdate(@PathVariable int id,Model model)
	{
		System.out.println("id :"+id);
	
		Optional<Experts> expert=mainService.getExpertById(id);
		model.addAttribute("expert", expert);

		
		return "FrontEnd/Admin/html/update_expert";
	}
	@PostMapping("/update_expert")
	public String UpdateExpert(@ModelAttribute Experts experts, Model model)
	{

	mainService.updateExpert(experts);

		return "FrontEnd/Admin/html/update_product_type";
	}
	//..........................update farmer..........................
	@GetMapping("/edit_farmer/{id}")
	public String farmerUpdate(@PathVariable int id,Model model)
	{
		System.out.println("id :"+id);
	
		Optional<Farmer> farmer=mainService.getFarmerById(id);
		model.addAttribute("farmer", farmer);

		
		return "FrontEnd/Farmer/html/update_farmer";
	}
	@PostMapping("/update_farmer")
	public String UpdateFarmer(@ModelAttribute Farmer farmer, Model model)
	{

	   mainService.updateFarmer(farmer);

		return "FrontEnd/Admin/html/update_product_type";
	}
	
	//........................update Customer...............................
	@GetMapping("/edit_customer/{id}")
	public String customerUpdate(@PathVariable int id,Model model)
	{
		System.out.println("id :"+id);
	
		Optional<Customer> customer=mainService.getCustomerById(id);
		model.addAttribute("customer", customer);

		
		return "FrontEnd/Customer/html/customer_update";
	}
	@PostMapping("/update_customer")
	public String UpdateCustomer(@ModelAttribute Customer customer, Model model)
	{

	mainService.updateCustomer(customer);

		return "FrontEnd/Admin/html/update_product_type";
	}
	
	
	
	//.........................farmer registration.............................
	
	
	
	
	@GetMapping("/farmer_registration")
	public String registration(Model model)
	{
		model.addAttribute("farmer", new Farmer());
		
		return "FrontEnd/Farmer/html/farmer_registration";
	}
	@GetMapping("/Afarmer_registration")
	public String Fregistration(Model model)
	{
		model.addAttribute("farmer", new Farmer());
		
		return "FrontEnd/Admin/html/farmer_registration";
	}
	@PostMapping("/farmer_registration")
	public String register(@Valid @ModelAttribute(value="farmer") Farmer farmer,BindingResult bindingResult ,Model model)
	{
		
		if(bindingResult.hasErrors())
		{	
			model.addAttribute("error_message", "validation error ");	
			return "FrontEnd/Farmer/html/farmer_registration";
		}else {
			mainService.saveFarmer(farmer);
			model.addAttribute("success_message", "User Added Succesfully");
			return "FrontEnd/Farmer/html/farmer_login";
		}		
	}
	
	@GetMapping("/my_questions/{firstname}")
	public String myQuestions(@RequestParam String firstname ,Model model)
	{
		System.out.println(firstname);
		List<AskQuestions> my_questions=mainService.getMyQuestions(firstname);
		model.addAttribute("my_questions",my_questions);
		
		return "FrontEnd/Farmer/html/my_questions";
	}
	
	
	
	//................................Ask Question ...................
	@GetMapping("/ask_question")
	public String askQuestion()
	{
		
		return "FrontEnd/Farmer/html/ask_question";
	}
	@PostMapping("/ask_question")
	public String askQuestion(@ModelAttribute AskQuestions askQuestions ,Model model) throws IOException
	{
	
		model.addAttribute("success_message", "Question Submitted");
		System.out.println(askQuestions.getFarmerName());
		System.out.println(askQuestions.getQuestion());
		
		mainService.saveQuestion(askQuestions);
		return "FrontEnd/Farmer/html/ask_question";
	}
	@GetMapping("/add_answer/{farmerName}")
	public String addAnswer(@PathVariable String farmerName ,Model model)
	{
		
		AskQuestions object=mainService.getQuestion(farmerName);
		model.addAttribute("object", object);
		return "FrontEnd/Admin/html/add_answer";
	}
	@PostMapping("/add_answer")
	public String addExpertAnswer( @ModelAttribute AskQuestions akAskQuestions,Model model)
	{
		
		System.out.println(akAskQuestions.getAnswer());
	//	mainService.addAnswer(akAskQuestions.getAnswer());
		
		return "FrontEnd/Admin/html/add_answer.html";
	}
	

	//............Expert Registration...........................
	@GetMapping("/add_expert")
	public String addExpert()
	{
		return "FrontEnd/Admin/html/add_expert";
	}
	@PostMapping("/add_expert")
	public String expertRegister( @ModelAttribute(value="expert") Experts expert,Model model)
	{
		mainService.saveExpert(expert);
			model.addAttribute("success_message", "User Added Succesfully");
			return "FrontEnd/Admin/html/add_expert";		
	}
	
	
	
	
	//..........................Publish Notification..................
	 @GetMapping("/publish_notification")
		public String publishNotification()
		{
			return "FrontEnd/Admin/html/publish_notification";
		}
	 
	 @RequestMapping(value="/publish_notification",method = RequestMethod.POST,consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
			public String saveNotifications(Notifications notifications , @ModelAttribute Notifications notifications2,
					@RequestPart(required = true,value = "notifyImage") MultipartFile notifyImage ,
					Model model) throws IOException
			{
		 
			String fileName = StringUtils.cleanPath(notifyImage.getOriginalFilename());
			System.out.println(fileName);

			List<Notifications> listOfNotifications = new ArrayList<>();

			//allImg = repo.findAll();
			listOfNotifications=mainService.getAllNotifications();
			

			String uploadDir = "notify-photos/" + (listOfNotifications.size()+1);

			try {

				//System.out.println("FileUploadUtil ");
			  FileUploader.saveDoc(uploadDir, fileName, notifyImage);

			  notifications.setImage(fileName);

		
			} 
			catch(IOException ie) {

				System.out.println("Error! file upload "+ie.getMessage());

			}
			
			notifications.setTitle(notifications2.getTitle());
			notifications.setDate(notifications2.getDate());
			notifications.setDescription(notifications2.getDescription());
							
			mainService.saveNotification(notifications);
			listOfNotifications=mainService.getAllNotifications();
			model.addAttribute("listOfNotifications", listOfNotifications);

			return "FrontEnd/Admin/html/publish_notification";
		}
	
	 @GetMapping("/about_us")
		public String aboutUs()
		{
			return "FrontEnd/about_us";
		}
	 
	 
	 
	 
	 
	 
	
	 
	@GetMapping("/all_product")
	public String allProduct( Model model) throws IOException
	{
		//InputStream is=null;
		List<Product> listOfProducts=mainService.getAllProduct();
	
		model.addAttribute("listOfProducts", listOfProducts);
		return "FrontEnd/Home/html/all_product";
	}
	
	
	@GetMapping("/all_product_admin")
	public String allProductAdmin( Model model)
	{
		List<Product> listOfProducts=mainService.getAllProduct();
		
		model.addAttribute("listOfProducts", listOfProducts);
		
		return "FrontEnd/AdminReports/html/all_products";
	}
	@GetMapping("/all_product_farmer")
	public String allProductFarmer( Model model)
	{
		model.addAttribute("allproduct", "this is all product");
		
		return "FrontEnd/Farmer/html/all_products";
	}
	@GetMapping("/notifications")
	public String notifications()
	{
		return "FrontEnd/Home/html/notifications";
	}
	@GetMapping("/all_notifications_expert")
	public String allNotificationsExpert(Model model)
	{
List<Notifications> listOfNotifications=mainService.getAllNotifications();
		
		model.addAttribute("listOfNotifications", listOfNotifications);
		return "FrontEnd/Admin/html/all_notifications_expert";
	}
	@GetMapping("/all_notifications")
	public String allNotifications(Model model)
	{
		List<Notifications> listOfNotifications=mainService.getAllNotifications();
		
		model.addAttribute("listOfNotifications", listOfNotifications);
		
		return "FrontEnd/AdminReports/html/all_notifications";
	}
	@GetMapping("/all_notifications_farmer")
	public String allNotificationsFarmer(Model model)
	{
List<Notifications> listOfNotifications=mainService.getAllNotifications();
		
		model.addAttribute("listOfNotifications", listOfNotifications);
		return "FrontEnd/Farmer/html/all_notifications";
	}
	
	
	@GetMapping("/all_experts")
	public String allExperts(Model model)
	{
		List<Experts> listOfExperts=mainService.getAllExpert();
		for(Experts QA:listOfExperts) {
			System.out.println(QA.getName());
		}
		model.addAttribute("listOfExperts", listOfExperts);
		return "FrontEnd/AdminReports/html/all_experts";
	}
	
	
	@GetMapping("/all_farmers")
	public String allFarmers(Model model)
	{
		List<Farmer> listOfFarmers=mainService.getAllFarmer();
		for(Farmer AF:listOfFarmers) {
			System.out.println(AF.getFirstname());
		}
		model.addAttribute("listOfFarmers", listOfFarmers);
		return "FrontEnd/AdminReports/html/all_farmers";
	}
	
	
	
	@GetMapping("/all_customers")
	public String allCustomers(Model model)
	{
		List<Customer> listOfCustomers=mainService.getAllCustomers();
		for(Customer AF:listOfCustomers) {
			System.out.println(AF.getName());
		}
		model.addAttribute("listOfCustomers", listOfCustomers);
		
		return "FrontEnd/AdminReports/html/all_customers";
	}
	@GetMapping("/all_questions")
	public String allQuestions(Model model)
	{
		List<AskQuestions> listOfQuestions =mainService.getAllQuestions();
		for(AskQuestions QA:listOfQuestions) {
			System.out.println(QA.getFarmerName());
		}
		model.addAttribute("listOfQuestions", listOfQuestions);
		return "FrontEnd/Home/html/all_questions";
	}
	@GetMapping("/all_questions_farmer")
	public String allQuestionsFarmer(Model model)
	{
		List<AskQuestions> listOfQuestions =mainService.getAllQuestions();
		for(AskQuestions QA:listOfQuestions) {
			System.out.println(QA.getFarmerName());
		}
		model.addAttribute("listOfQuestions", listOfQuestions);
		return "FrontEnd/Farmer/html/all_questions";
	}
	@GetMapping("/all_questions_expert")
	public String allQuestionsE(Model model)
	{
	  List<AskQuestions> listOfQuestions	=mainService.getAllQuestions();
	  model.addAttribute("listOfQuestions", listOfQuestions);
		return "FrontEnd/Admin/html/all_questions_expert";
	}
	
	
	
	
	//...............Contact US.................................
	@GetMapping("/contact_us")
	public String contactUsForm()
	{
		
		
		return "FrontEnd/Home/html/contact_us";
	}
	@PostMapping("/contact_us")
	public String contactUs(@ModelAttribute ContactUs contactUs,Model model)
	{
		
		System.out.println(contactUs.getMessage());
		model.addAttribute("success_message", "User Added Succesfully");
		
		return "FrontEnd/Home/html/contact_us";
	}
	
	
}
