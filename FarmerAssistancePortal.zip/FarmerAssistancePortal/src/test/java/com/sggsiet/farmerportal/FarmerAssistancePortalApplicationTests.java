package com.sggsiet.farmerportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmerAssistancePortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
